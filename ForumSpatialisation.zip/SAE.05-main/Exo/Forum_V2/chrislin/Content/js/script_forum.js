// Récupérez les boutons de navigation
const previousPageButton = document.getElementById('previous-page');
const nextPageButton = document.getElementById('next-page')

// Écoutez les clics sur les boutons
previousPageButton.addEventListener('click', navigateToPreviousPage);
nextPageButton.addEventListener('click', navigateToNextPage);

// Fonctions de navigation (vous devrez les implémenter)
function navigateToPreviousPage() {
    // Mettez ici la logique pour passer à la page précédente
}

function navigateToNextPage() {
    // Mettez ici la logique pour passer à la page suivante
}



