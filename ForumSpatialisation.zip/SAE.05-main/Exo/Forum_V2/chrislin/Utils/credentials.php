<?php

$dsn="mysql:host=localhost;dbname=forum";
$login="root";
$mdp="";

?>