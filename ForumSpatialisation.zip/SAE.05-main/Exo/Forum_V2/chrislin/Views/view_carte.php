<?php require_once "view_begin.php" ?>
<link rel="stylesheet" href="Content/css/carte.css">
<title> Carte de Naruto </title>
</head>
<body>
    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Naruto_World_Map.svg/1280px-Naruto_World_Map.svg.png" alt="Carte" usemap="#map" class="carte">

    <map name="map">
      
        
        <area target="" alt="" title="Sujets" href="/Exo/Forum_V2/chrislin/?controller=forum" coords="466,233,400,283" shape="rect">
        <area target="" alt="" title="" href="/Exo/Forum_V2/chrislin/?controller=forum" coords="" shape="0">
        
        <area target="" alt="" title="Galerie Photo" href="/Exo/Forum_V2/chrislin/?controller=forum&action=galerie" coords="390,630,555,820" shape="rect">
        <area target="" alt="" title="" href="/Exo/Forum_V2/chrislin/?controller=forum" coords="" shape="0">

        <area target="" alt="" title="Spatialisation" href="/Exo/Forum_V2/chrislin/?controller=forum&action=map" coords="729,506,663,556" shape="rect">
        <area target="" alt="" title="" href="" coords="" shape="0"> 

        <area target="" alt="" title="Profil" href="/Exo/Forum_V2/chrislin/?controller=profil" coords="1143,198,1077,248" shape="rect">
        <area target="" alt="" title="" href="" coords="" shape="0">

        <area target="" alt="" title="Message privé" href="/Exo/Forum_V2/chrislin/?controller=mp" coords="1279,593,1252,652" shape="rect">
        <area target="" alt="" title="" href="" coords="" shape="0"> 
    
    </map>
</body>
</html>
