<?php require "view_begin.php"; ?>
<?php require "../Content/js/script.js"; ?>

<div class="container text-center" id="mainContent">
        <h1 class="my-4">Bienvenue sur le Forum Naruto</h1>
        <img src="/Content/img/logo.png" alt="Logo Naruto" class="mb-4 logo-small"> 
        <button class="btn btn-primary btn-lg" id="loginButton">Connexion</button>
        <button class="btn btn-secondary btn-lg" id="registerButton">Inscription</button>


        
<?php require "view_begin.php"; ?>
