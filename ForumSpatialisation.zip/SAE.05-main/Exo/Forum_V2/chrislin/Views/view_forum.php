<?php require_once "view_begin.php" ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Forum</title>
    
</head>
<body>
    <div id="forum-container">
        <h1>Forum de discussion</h1>
        <div id="posts-container"></div>
        <div id="form-container">
            <label for="username">Nom d'utilisateur:</label>
            <input type="text" id="username" placeholder="Entrez votre nom d'utilisateur">
            <label for="message">Message:</label>
            <textarea id="message" placeholder="Entrez votre message"></textarea>
            <button onclick="addPost()">Ajouter un message</button>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>




<?php require_once "view_end.php" ?><?php require_once "view_begin.php" ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Forum</title>
    
</head>
<body>
    <div id="forum-container">
        <h1>Forum de discussion</h1>
        <div id="posts-container"></div>
        <div id="form-container">
            <label for="username">Nom d'utilisateur:</label>
            <input type="text" id="username" placeholder="Entrez votre nom d'utilisateur">
            <label for="message">Message:</label>
            <textarea id="message" placeholder="Entrez votre message"></textarea>
            <button onclick="addPost()">Ajouter un message</button>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>




<?php require_once "view_end.php" ?>