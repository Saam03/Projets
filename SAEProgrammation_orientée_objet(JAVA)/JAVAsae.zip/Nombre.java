public class Nombre extends Operation {
	
public int valeurNombre;

	public Nombre() {
		 this.valeurNombre=valeurNombre;
	}
	
	public int GetNombre() {
		return this.valeurNombre;
	}
	
	public GetOperation toString(){
		return this.valeurNombre;
	}	
	
	
	
	
	
}
