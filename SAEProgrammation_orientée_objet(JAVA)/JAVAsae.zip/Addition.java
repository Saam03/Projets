public class Addition extends Operation {
	
private Nombre n1;
private Nombre n2;

public Addition(Nombre n1, Nombre n2){
	super(n1,n2);
	}
	

public int Valeur (){
	somme1 = this.n1=getOperande1();
	somme2 = this.n2=getOperande2();
	return somme1 + somme2;
}

public GetResultat toString(){
		return(somme1 + "+" + somme2 + "=" + (somme1+somme2));
	}	
	
	
	
}
