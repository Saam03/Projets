public abstract class Expression {

private int nb;

public abstract int Valeur();

}
